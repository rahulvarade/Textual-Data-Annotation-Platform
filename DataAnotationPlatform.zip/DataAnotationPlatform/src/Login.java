

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.DriverManager;
import java.sql.ResultSet;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.*; 

import java.sql.*;  
/**
 * Servlet implementation class Login
 */
@WebServlet(asyncSupported = true, urlPatterns = { "/Login" })
public class Login extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub

		PrintWriter pw = response.getWriter();
		String email=request.getParameter("email");
		String pass=request.getParameter("pass");
		//System.out.println(email+" "+pass);
		//pw.println(email+" "+pass);
		
		
		//checking if email and password is valid or not
		try{ 
			
			//step1 load the driver class  
			Class.forName("oracle.jdbc.driver.OracleDriver");  
			  
			//step2 create  the connection object  
			Connection con=DriverManager.getConnection(  
			"jdbc:oracle:thin:@localhost:1521:xe","system","system");  
			  
			//step3 create the statement object  
			Statement stmt=con.createStatement();  
			  
			//step4 execute query  
			String query="select password from Users where email like "+"'"+email+"'";
			ResultSet rs=stmt.executeQuery(query);  
			while(rs.next())  
			{
				String res=rs.getString(1);
				if(res.equals(pass)) {
					pw.println("Login Successfull");
					HttpSession session=request.getSession();  
				    session.setAttribute("email",email); //setting login session as email
				    
				    //getting session variable
				    HttpSession sess=request.getSession(false);  
			        String n=(String)sess.getAttribute("email"); 
			        //response.sendRedirect("C:/Users/HP/eclipse-workspace/DataAnotationPlatform/WebContent/upload.jsp");
				}
				else
				{
					pw.println("Login Unsuccessfull");
				}
			}
			
			//step5 close the connection object  
			con.close();  
			  
			}catch(Exception e){ System.out.println(e);}  
		
		pw.close();

	}

}






