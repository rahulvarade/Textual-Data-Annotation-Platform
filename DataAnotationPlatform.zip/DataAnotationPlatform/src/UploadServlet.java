

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import java.io.*;  
import javax.servlet.ServletException;  
import javax.servlet.http.*; 

import com.oreilly.servlet.MultipartRequest;
import com.oreilly.servlet.multipart.DefaultFileRenamePolicy;
import com.sun.jmx.snmp.Timestamp;

import java.util.*;


@WebServlet(asyncSupported = true, urlPatterns = { "/UploadServlet" }) 

public class UploadServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	@SuppressWarnings("unchecked")
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{

		MultipartRequest m=new MultipartRequest(request,"WebContent/Datasets",Integer.MAX_VALUE, new DefaultFileRenamePolicy());
		PrintWriter pw = response.getWriter();
		
		//taking file name
		String fn="",file_name="";
		Path dir = Paths.get("C:/Users/HP/eclipse-workspace/DataAnotationPlatform/Datasets");  // specify your directory
		Optional<Path> lastFilePath = Files.list(dir)    // here we get the stream with full directory listing
			.filter(f -> !Files.isDirectory(f))  // exclude subdirectories from listing
			.max(Comparator.comparingLong(f -> f.toFile().lastModified()));  // finally get the last file using simple comparator by lastModified field
		if ( lastFilePath.isPresent() ) // your folder may be empty
		{
			fn=lastFilePath.toString();
			//pw.println(file_name);
			file_name=fn.substring(9, fn.length()-1);
		} 	
		
		
	
		//Adding status and annotation columns in excel file wih default values
		FileInputStream fis = new FileInputStream(new File(file_name));
	   	XSSFWorkbook workbook = new XSSFWorkbook(fis);
	   	XSSFSheet spreadsheet = workbook.getSheetAt(0);
	   	Iterator < Row >  rowIterator = spreadsheet.iterator();
	   	XSSFRow row;
	   	while (rowIterator.hasNext()) 
	   	{
	   		row = (XSSFRow) rowIterator.next();
	      	if(row.getRowNum()==0)
	      	{
	      		
	      		int last_cell = row.getLastCellNum();
	      		Cell x = row.getCell(last_cell-1);
	      		Cell status=row.createCell(last_cell);
	        	Cell annotation=row.createCell(last_cell+1);
	        	status.setCellValue("status");
		    	annotation.setCellValue("annotation");
	      	}
	      	else
	      	{
	      			
	      		int last_cell = row.getLastCellNum();
	      		Cell x = row.getCell(last_cell-1);
		      	Cell status=row.createCell(last_cell);
		        Cell annotation=row.createCell(last_cell+1);
		        status.setCellValue("0");
			    annotation.setCellValue("NULL");	
	      	}
	   	}	
	   	fis.close();
		FileOutputStream fos=new FileOutputStream(file_name);
		workbook.write(fos);
	 	workbook.close();
		fos.close();
		
		
		
		//closing above variables for saving changes in excel file
		
		
		
		
		
		
		String dname =m.getParameter("dname");
		
		String desc=m.getParameter("desc");
		
		int total_records=Integer.parseInt(m.getParameter("total_records"));
	    HttpSession sess=request.getSession(false);  
        String email=(String)sess.getAttribute("email");
		int annotated_records=0;
		Timestamp timestamp = new Timestamp(System.currentTimeMillis());
		String tmp=""+timestamp;
		String ts=tmp.substring( tmp.lastIndexOf("=")+2, tmp.length()-1);
		String dbcname =m.getParameter("dbcname");
		
		//pw.println("DatabaseName:"+dname+" Desc:"+desc+" FileName:"+file_name+" TotalRecords:"+total_records+" Annotated_records:"+annotated_records+" Email:"+email+" TimeStamp:"+ts);
		
		//Putting data in Datasets database 
		try
		{ 
			Class.forName("oracle.jdbc.driver.OracleDriver");  
			Connection con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","system","system");  
			Statement stmt=con.createStatement();  
			
			//saving details in Datasets table
			String query="INSERT INTO DATASETS(dataset_name,dataset_desc,path,total_records,annotated_records,uploader,upload_date,data_column)" + 
					"VALUES"+"("+"'"+dname+"'"+","+"'"+desc+"'"+","+"'"+file_name+"'"+","+"'"+total_records+"'"+","+"'"+annotated_records+"'"+","+"'"+email+"'"+","+"'"+ts+"'"+","+"'"+dbcname+"'"+")";
			System.out.println(query);
			stmt.executeUpdate(query);   
			
			// Saving details in Dataset_Label table
			ResultSet dataset_id=stmt.executeQuery("select dataset_id from DATASETS where uploader like "+"'"+email+"'"+"and upload_date like"+"'"+ts+"'"); 
			String ds_id = "";
			while(dataset_id.next())
			{
				//get dataset_id of dataset just entered.
				ds_id = dataset_id.getString(1);
				break;
			}
			
			int label_count = Integer.parseInt(m.getParameter("label_count"));
			int n=0;
			for(int i=1;i<=label_count;i++)
			{
				//pw.println(m.getParameter("label_"+i));
				String label=m.getParameter("label_"+i);
				String query1="INSERT INTO DATASET_LABEL(DATASET_ID,LABEL,LABEl_COUNT) VALUES ('"+ds_id+"','"+label+"','"+n+"')"; 
				stmt.executeUpdate(query1);
			}
			con.close();  
			  
		}
		catch(Exception e){ System.out.println(e);}
				
			//getting database id and storing in labels table (to check..)
		
			
			
		
		
		
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		doGet(request, response);
	}

}
